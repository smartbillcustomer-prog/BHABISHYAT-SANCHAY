# BHABISHYAT SANCHAY Android Application

**BHABISHYAT SANCHAY** is a production-ready, release-hardened Android application built with Kotlin, Jetpack Compose, and modern Android WebView architecture. The app connects directly to the cloud platform at `https://smartbill-vytm.onrender.com/`.

---

## Security & Play Protect Compliance

1. **Google Play Protect & Zero-Trust Security**:
   - **No Cleartext Traffic**: `android:usesCleartextTraffic="false"` and OS-level `network_security_config.xml` strictly enforce modern TLS/HTTPS.
   - **Strict Certificate Validation**: SSL errors are never bypassed (`handler.cancel()`). Any untrusted, expired, or invalid SSL connection is terminated immediately.
   - **Safe Browsing Integration**: `safeBrowsingEnabled = true` enables Google Safe Browsing / Play Protect real-time malware and phishing protection.
   - **Sandbox Isolation**: Local file access (`allowFileAccess = false`, `allowContentAccess = false`) is disabled to prevent malicious web scripts from accessing local storage.
   - **Debug Code Elimination**: WebView remote debugging is explicitly disabled (`setWebContentsDebuggingEnabled(false)`). All debug dependencies are excluded from release builds.
   - **Data Extraction & Backup Protection**: `data_extraction_rules.xml` and `backup_rules.xml` exclude webview cache and sensitive session state from unencrypted cloud backups.

2. **Google Play Console Release Requirements**:
   - **Package Name (Application ID)**: `com.bhabishyat.sanchay`
   - **App Title**: `BHABISHYAT SANCHAY` (18 characters, well within the $\le 30$ character Play Console policy).
   - **Target SDK**: Android 16 (API 36) - exceeds Google Play target API requirements.
   - **Min SDK**: Android 7.0 (API 24).
   - **Permissions Minimization**: Only `INTERNET` and `ACCESS_NETWORK_STATE` are declared. Zero sensitive or dangerous permissions required. File uploads use the zero-permission Android Photo Picker and Storage Access Framework (`ACTION_OPEN_DOCUMENT`).

---

## Build & Release Instructions

### 1. Opening the Project in Android Studio
1. Launch **Android Studio** (Ladybug / Meerkat or later).
2. Select **File > Open…** and choose this project's root folder.
3. Gradle will sync all dependencies automatically.

### 2. Building a Debug APK
```bash
gradle :app:assembleDebug
```
Output path: `app/build/outputs/apk/debug/app-debug.apk`

### 3. Generating a Signed Android App Bundle (AAB) for Google Play Console
The upload keystore `my-upload-key.jks` is pre-configured with alias `upload`:
```bash
STORE_PASSWORD=android KEY_PASSWORD=android gradle :app:bundleRelease
```
Output path:
`app/build/outputs/bundle/release/app-release.aab`
This `.aab` file is ready for direct upload to **Google Play Console > Production (or Internal / Closed testing)** track.

### 4. Generating a Signed Release APK
To generate a standalone signed APK:
```bash
STORE_PASSWORD=android KEY_PASSWORD=android gradle :app:assembleRelease
```
Output path:
`app/build/outputs/apk/release/app-release.apk`

### 5. Testing on a Physical Android Device
1. Enable **Developer Options** & **USB Debugging** on your Android smartphone.
2. Connect your device via USB.
3. Run directly from Android Studio, or install via terminal:
```bash
adb install -r app/build/outputs/apk/release/app-release.apk
```

---

## Application Identity
- **Application Name**: BHABISHYAT SANCHAY
- **Package Name**: `com.bhabishyat.sanchay`
- **Target URL**: `https://smartbill-vytm.onrender.com/`
- **Min SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 16 (API 36)


---

## GitHub Actions: APK Build

This project includes `.github/workflows/android-apk.yml`.

1. Create a GitHub repository and upload the **contents** of this project ZIP to the repository root. Keep the `.github` folder.
2. Push to `main` or `master`, or open **Actions → Build Android APK → Run workflow**.
3. Open the completed workflow run.
4. Under **Artifacts**, download `BHABISHYAT-SANCHAY-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds a **debug APK** for installation and testing. It is not a Play Store release-signed APK. A release APK requires your own signing keystore and passwords configured as protected GitHub Actions secrets. Never commit a keystore or signing passwords to the repository.

### Render server

The Android WebView start URL is configured in:
`app/src/main/java/com/example/webview/SmartBillConstants.kt`

Current URL:
`https://smartbill-vytm.onrender.com/`

The Android Internet and network-state permissions have been corrected to the proper Android permission namespace.
