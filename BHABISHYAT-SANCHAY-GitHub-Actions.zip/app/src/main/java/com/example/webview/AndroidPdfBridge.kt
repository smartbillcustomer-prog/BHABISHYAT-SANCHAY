package com.example.webview

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap

class AndroidPdfBridge(
  private val context: Context,
  private val webViewProvider: () -> WebView?,
  private val originChecker: () -> String?
) {

  private val mainHandler = Handler(Looper.getMainLooper())

  // Chunked transfers map: transferId -> TransferSession
  private val transferSessions = ConcurrentHashMap<String, TransferSession>()

  private data class TransferSession(
    val totalChunks: Int,
    val fileName: String?,
    val mimeType: String?,
    val action: String?,
    val chunks: Array<String?>
  )

  @JavascriptInterface
  fun onPdfBlobReceived(
    base64Data: String?,
    rawFileName: String?,
    mimeType: String?,
    action: String?
  ) {
    if (base64Data.isNullOrBlank()) {
      showToast("Error: Received empty PDF data")
      return
    }

    val pdfBytes = PdfManager.decodeBase64Pdf(base64Data)
    if (pdfBytes == null || pdfBytes.isEmpty()) {
      showToast("Error: Failed to decode PDF document")
      return
    }

    mainHandler.post {
      processPdfAction(pdfBytes, rawFileName, action ?: "download")
    }
  }

  @JavascriptInterface
  fun startChunkedTransfer(
    transferId: String,
    totalChunks: Int,
    fileName: String?,
    mimeType: String?,
    action: String?
  ) {
    if (totalChunks <= 0 || totalChunks > 500) {
      showToast("Invalid file transfer request")
      return
    }
    transferSessions[transferId] = TransferSession(
      totalChunks = totalChunks,
      fileName = fileName,
      mimeType = mimeType,
      action = action,
      chunks = arrayOfNulls(totalChunks)
    )
  }

  @JavascriptInterface
  fun receiveChunk(transferId: String, chunkIndex: Int, chunkData: String) {
    val session = transferSessions[transferId] ?: return
    if (chunkIndex in 0 until session.totalChunks) {
      session.chunks[chunkIndex] = chunkData
    }
  }

  @JavascriptInterface
  fun finalizeTransfer(transferId: String) {
    val session = transferSessions.remove(transferId) ?: return
    val stringBuilder = StringBuilder()
    for (i in 0 until session.totalChunks) {
      val chunk = session.chunks[i]
      if (chunk == null) {
        showToast("Error: Missing PDF transfer chunk")
        return
      }
      stringBuilder.append(chunk)
    }

    val fullBase64 = stringBuilder.toString()
    val pdfBytes = PdfManager.decodeBase64Pdf(fullBase64)
    if (pdfBytes == null || pdfBytes.isEmpty()) {
      showToast("Error: Failed to reassemble PDF document")
      return
    }

    mainHandler.post {
      processPdfAction(pdfBytes, session.fileName, session.action ?: "download")
    }
  }

  @JavascriptInterface
  fun sharePdfBase64(
    base64Data: String?,
    fileName: String?,
    mimeType: String?,
    title: String?,
    text: String?
  ) {
    if (base64Data.isNullOrBlank()) {
      showToast("Error: No PDF content to share")
      return
    }
    val pdfBytes = PdfManager.decodeBase64Pdf(base64Data) ?: run {
      showToast("Error: Could not decode PDF for sharing")
      return
    }

    mainHandler.post {
      PdfManager.sharePdf(
        context = context,
        pdfBytes = pdfBytes,
        rawFileName = fileName,
        subject = title ?: "BHABISHYAT SANCHAY Statement",
        textMessage = text ?: "Customer Statement PDF",
        preferWhatsApp = true
      )
    }
  }

  @JavascriptInterface
  fun shareText(title: String?, text: String?, url: String?) {
    mainHandler.post {
      val shareBody = buildString {
        if (!text.isNullOrBlank()) append(text)
        if (!url.isNullOrBlank()) {
          if (isNotEmpty()) append("\n\n")
          append(url)
        }
      }
      val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, title ?: "BHABISHYAT SANCHAY")
        putExtra(android.content.Intent.EXTRA_TEXT, shareBody)
      }
      val chooser = android.content.Intent.createChooser(intent, "Share via…")
      chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(chooser)
    }
  }

  @JavascriptInterface
  fun printCurrentPage() {
    mainHandler.post {
      val webView = webViewProvider()
      if (webView == null) {
        showToast("Cannot print: Page is not ready")
        return@post
      }
      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        showToast("Printing service unavailable")
        return@post
      }
      val jobName = "BHABISHYAT_SANCHAY_${System.currentTimeMillis()}"
      val printAdapter = webView.createPrintDocumentAdapter(jobName)
      printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
  }

  @JavascriptInterface
  fun onPdfBlobError(errorMessage: String?) {
    showToast("PDF generation failed: ${errorMessage ?: "Unknown error"}")
  }

  private fun processPdfAction(pdfBytes: ByteArray, fileName: String?, action: String) {
    when (action.lowercase()) {
      "print" -> {
        PdfManager.printPdfBytes(context, pdfBytes, fileName ?: "Statement.pdf")
      }
      "share_whatsapp" -> {
        PdfManager.sharePdf(
          context = context,
          pdfBytes = pdfBytes,
          rawFileName = fileName,
          preferWhatsApp = true
        )
      }
      "share_drive", "share" -> {
        PdfManager.sharePdf(
          context = context,
          pdfBytes = pdfBytes,
          rawFileName = fileName,
          preferWhatsApp = false
        )
      }
      else -> { // Default: download
        PdfManager.savePdfToDownloads(context, pdfBytes, fileName)
      }
    }
  }

  private fun showToast(message: String) {
    mainHandler.post {
      Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
  }
}
