package com.example.webview

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient

class SmartBillWebViewClient(
  private val context: Context,
  private val onLoadingChanged: (isLoading: Boolean) -> Unit,
  private val onErrorStateChanged: (WebViewErrorState) -> Unit,
  private val onPageFinishedTitle: (title: String?, url: String?) -> Unit,
  private val onBlobUrlIntercepted: ((url: String) -> Unit)? = null
) : WebViewClient() {

  override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
    val url = request?.url ?: return false
    val urlString = url.toString()
    val scheme = url.scheme?.lowercase() ?: return false

    // Intercept blob URLs to prevent webview navigation errors
    if (scheme == "blob" || scheme == "data") {
      onBlobUrlIntercepted?.invoke(urlString)
      return true
    }

    // Handle WhatsApp specific links
    if (scheme == "whatsapp" ||
        urlString.contains("api.whatsapp.com/send", ignoreCase = true) ||
        urlString.contains("wa.me/", ignoreCase = true)) {
      return try {
        val intent = Intent(Intent.ACTION_VIEW, url).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
      } catch (e: Exception) {
        // Fallback to open in external browser or show chooser
        try {
          val chooser = Intent.createChooser(Intent(Intent.ACTION_VIEW, url), "Open WhatsApp…").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
          context.startActivity(chooser)
        } catch (_: Exception) {}
        true
      }
    }

    // Handle intent:// URI schemes
    if (scheme == "intent") {
      return try {
        val parsedIntent = Intent.parseUri(urlString, Intent.URI_INTENT_SCHEME).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(parsedIntent)
        true
      } catch (e: Exception) {
        true
      }
    }

    // Handle non-web URI schemes (phone calls, emails, messaging)
    if (scheme != "http" && scheme != "https") {
      return try {
        val intent = Intent(Intent.ACTION_VIEW, url).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        true
      } catch (e: Exception) {
        true
      }
    }

    // Keep navigation inside WebView
    return false
  }

  override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
    super.onPageStarted(view, url, favicon)
    onLoadingChanged(true)
    injectNativeBridgePolyfills(view)
  }

  override fun onPageFinished(view: WebView?, url: String?) {
    super.onPageFinished(view, url)
    onLoadingChanged(false)
    onPageFinishedTitle(view?.title, url)
    injectNativeBridgePolyfills(view)
  }

  private fun injectNativeBridgePolyfills(view: WebView?) {
    val jsCode = """
      (function() {
        if (window.__BHABISHYAT_BRIDGE_INJECTED__) return;
        window.__BHABISHYAT_BRIDGE_INJECTED__ = true;

        // 1. Native Print Override
        window.print = function() {
          if (window.AndroidPdfBridge) {
            window.AndroidPdfBridge.printCurrentPage();
          }
        };

        // 2. Web Share API Polyfill for WhatsApp & Native Sharing
        if (typeof navigator !== 'undefined') {
          navigator.canShare = function(data) {
            return true;
          };
          navigator.share = function(data) {
            return new Promise(function(resolve, reject) {
              try {
                if (data && data.files && data.files.length > 0) {
                  var file = data.files[0];
                  var fileName = file.name || data.title || "statement.pdf";
                  var mimeType = file.type || "application/pdf";
                  var reader = new FileReader();
                  reader.onloadend = function() {
                    if (window.AndroidPdfBridge) {
                      window.AndroidPdfBridge.sharePdfBase64(
                        reader.result,
                        fileName,
                        mimeType,
                        data.title || "BHABISHYAT SANCHAY Statement",
                        data.text || ""
                      );
                      resolve();
                    } else {
                      reject(new Error("Native share bridge unavailable"));
                    }
                  };
                  reader.onerror = function(err) {
                    reject(err || new Error("Failed to read file"));
                  };
                  reader.readAsDataURL(file);
                } else if (data && (data.text || data.url)) {
                  if (window.AndroidPdfBridge) {
                    window.AndroidPdfBridge.shareText(data.title || "", data.text || "", data.url || "");
                    resolve();
                  } else {
                    resolve();
                  }
                } else {
                  resolve();
                }
              } catch (err) {
                reject(err);
              }
            });
          };
        }

        // 3. Responsive viewport assurance
        var meta = document.querySelector('meta[name="viewport"]');
        if (!meta) {
          meta = document.createElement('meta');
          meta.name = 'viewport';
          meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes';
          document.getElementsByTagName('head')[0].appendChild(meta);
        }
      })();
    """.trimIndent()

    view?.evaluateJavascript(jsCode, null)
  }

  override fun onReceivedError(
    view: WebView?,
    request: WebResourceRequest?,
    error: WebResourceError?
  ) {
    super.onReceivedError(view, request, error)
    if (request?.isForMainFrame == true) {
      val failingUrl = request.url?.toString()
      val errorCode = error?.errorCode ?: 0
      val description = error?.description?.toString() ?: "Connection failed"

      when (errorCode) {
        ERROR_HOST_LOOKUP, ERROR_CONNECT, ERROR_TIMEOUT, ERROR_FAILED_SSL_HANDSHAKE -> {
          onErrorStateChanged(WebViewErrorState.Offline(failingUrl))
        }
        else -> {
          onErrorStateChanged(WebViewErrorState.GeneralError(failingUrl, errorCode, description))
        }
      }
    }
  }

  override fun onReceivedHttpError(
    view: WebView?,
    request: WebResourceRequest?,
    errorResponse: WebResourceResponse?
  ) {
    super.onReceivedHttpError(view, request, errorResponse)
    if (request?.isForMainFrame == true) {
      val statusCode = errorResponse?.statusCode ?: 200
      if (statusCode in 500..599) {
        onErrorStateChanged(
          WebViewErrorState.GeneralError(
            failingUrl = request.url?.toString(),
            errorCode = statusCode,
            description = "Server error ($statusCode). The service may be restarting."
          )
        )
      }
    }
  }

  override fun onReceivedSslError(
    view: WebView?,
    handler: SslErrorHandler?,
    error: SslError?
  ) {
    // CRITICAL: Never bypass SSL certificate validation
    handler?.cancel()

    val failingUrl = error?.url ?: view?.url
    val description = when (error?.primaryError) {
      SslError.SSL_EXPIRED -> "The security certificate has expired."
      SslError.SSL_IDMISMATCH -> "Hostname mismatch on certificate."
      SslError.SSL_UNTRUSTED -> "The certificate authority is not trusted."
      SslError.SSL_DATE_INVALID -> "The date of the certificate is invalid."
      else -> "A secure SSL connection could not be verified."
    }

    onErrorStateChanged(WebViewErrorState.SslError(failingUrl, description))
  }
}
