package com.example.webview

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfManager {

  private const val NOTIFICATION_CHANNEL_ID = "pdf_downloads"
  private const val NOTIFICATION_CHANNEL_NAME = "PDF Downloads"

  fun sanitizeFileName(rawName: String?, fallback: String = "BHABISHYAT_SANCHAY_Statement.pdf"): String {
    if (rawName.isNullOrBlank()) return fallback
    // Remove query parameters or path segments
    val nameWithoutParams = rawName.substringBefore('?').substringBefore('#')
    val cleanName = File(nameWithoutParams).name
      .replace(Regex("[^a-zA-Z0-9._\\-()]"), "_")
      .trim()
    val finalName = if (cleanName.isBlank()) fallback else cleanName
    return if (!finalName.endsWith(".pdf", ignoreCase = true)) "$finalName.pdf" else finalName
  }

  fun decodeBase64Pdf(base64Data: String): ByteArray? {
    return try {
      val pureBase64 = if (base64Data.contains(",")) {
        base64Data.substringAfter(",")
      } else {
        base64Data
      }.trim()

      try {
        java.util.Base64.getDecoder().decode(pureBase64)
      } catch (_: Throwable) {
        android.util.Base64.decode(pureBase64, android.util.Base64.DEFAULT)
      }
    } catch (e: Exception) {
      null
    }
  }

  /**
   * Saves the PDF to the Android public Downloads directory using MediaStore on API 29+
   * or standard public directory on older APIs.
   */
  fun savePdfToDownloads(context: Context, pdfBytes: ByteArray, rawFileName: String?): Uri? {
    val fileName = sanitizeFileName(rawFileName)
    if (pdfBytes.isEmpty()) {
      Toast.makeText(context, "Error: PDF data is empty", Toast.LENGTH_SHORT).show()
      return null
    }

    try {
      val savedUri: Uri?
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val contentValues = ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
          put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
          put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            "${Environment.DIRECTORY_DOWNLOADS}/BHABISHYAT_SANCHAY"
          )
          put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
          ?: throw IllegalStateException("Could not create MediaStore record")

        resolver.openOutputStream(uri)?.use { os ->
          os.write(pdfBytes)
          os.flush()
        }

        contentValues.clear()
        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, contentValues, null, null)
        savedUri = uri
      } else {
        @Suppress("DEPRECATION")
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val appFolder = File(downloadsDir, "BHABISHYAT_SANCHAY").apply { if (!exists()) mkdirs() }
        val targetFile = File(appFolder, fileName)
        FileOutputStream(targetFile).use { os ->
          os.write(pdfBytes)
          os.flush()
        }
        savedUri = Uri.fromFile(targetFile)
      }

      Toast.makeText(context, "PDF saved to Downloads: $fileName", Toast.LENGTH_LONG).show()
      notifyPdfDownloaded(context, fileName, savedUri)
      return savedUri
    } catch (e: Exception) {
      Toast.makeText(
        context,
        "Failed to save PDF: ${e.localizedMessage ?: "Storage error"}",
        Toast.LENGTH_LONG
      ).show()
      return null
    }
  }

  /**
   * Shares the PDF using Android's native ACTION_SEND chooser.
   * If [preferWhatsApp] is true, tries to target WhatsApp directly, with graceful fallback to chooser.
   */
  fun sharePdf(
    context: Context,
    pdfBytes: ByteArray,
    rawFileName: String?,
    subject: String = "BHABISHYAT SANCHAY Statement",
    textMessage: String = "Here is the requested customer statement PDF from BHABISHYAT SANCHAY.",
    preferWhatsApp: Boolean = false
  ) {
    val fileName = sanitizeFileName(rawFileName)
    if (pdfBytes.isEmpty()) {
      Toast.makeText(context, "Error: PDF data is empty", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      // Save temporarily to app cache
      val cacheDir = File(context.cacheDir, "shared_pdfs").apply { if (!exists()) mkdirs() }
      val cacheFile = File(cacheDir, fileName)
      FileOutputStream(cacheFile).use { os ->
        os.write(pdfBytes)
        os.flush()
      }

      val contentUri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        cacheFile
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, contentUri)
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, textMessage)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      if (preferWhatsApp) {
        val whatsappInstalled = isPackageInstalled(context, "com.whatsapp") ||
                               isPackageInstalled(context, "com.whatsapp.w4b")
        if (whatsappInstalled) {
          val pkg = if (isPackageInstalled(context, "com.whatsapp")) "com.whatsapp" else "com.whatsapp.w4b"
          shareIntent.setPackage(pkg)
          val chooser = Intent.createChooser(shareIntent, "Share Statement via WhatsApp")
          chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(chooser)
          return
        } else {
          Toast.makeText(
            context,
            "WhatsApp not installed. Opening share options…",
            Toast.LENGTH_SHORT
          ).show()
        }
      }

      // Default to native chooser (supports Google Drive, WhatsApp, Gmail, etc.)
      val chooser = Intent.createChooser(shareIntent, "Share PDF Statement via…")
      chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(chooser)
    } catch (e: Exception) {
      Toast.makeText(
        context,
        "Sharing failed: ${e.localizedMessage ?: "Unknown error"}",
        Toast.LENGTH_LONG
      ).show()
    }
  }

  /**
   * Prints the generated PDF file using Android's native PrintManager.
   */
  fun printPdfBytes(context: Context, pdfBytes: ByteArray, documentName: String) {
    if (pdfBytes.isEmpty()) {
      Toast.makeText(context, "Error: No PDF data to print", Toast.LENGTH_SHORT).show()
      return
    }

    try {
      val tempFile = File.createTempFile("print_", ".pdf", context.cacheDir)
      FileOutputStream(tempFile).use { os ->
        os.write(pdfBytes)
        os.flush()
      }

      val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
      if (printManager == null) {
        Toast.makeText(context, "Printing service unavailable on this device", Toast.LENGTH_SHORT).show()
        return
      }

      val jobName = "Print - ${sanitizeFileName(documentName)}"
      val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(
          oldAttributes: PrintAttributes?,
          newAttributes: PrintAttributes?,
          cancellationSignal: CancellationSignal?,
          callback: LayoutResultCallback?,
          extras: Bundle?
        ) {
          if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
          }
          val info = PrintDocumentInfo.Builder(jobName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .build()
          callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
          pages: Array<out PageRange>?,
          destination: ParcelFileDescriptor?,
          cancellationSignal: CancellationSignal?,
          callback: WriteResultCallback?
        ) {
          try {
            FileInputStream(tempFile).use { input ->
              FileOutputStream(destination?.fileDescriptor).use { output ->
                input.copyTo(output)
              }
            }
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
          } catch (e: Exception) {
            callback?.onWriteFailed(e.message)
          }
        }

        override fun onFinish() {
          super.onFinish()
          tempFile.delete()
        }
      }

      printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    } catch (e: Exception) {
      Toast.makeText(context, "Print failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
  }

  private fun isPackageInstalled(context: Context, packageName: String): Boolean {
    return try {
      context.packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
      true
    } catch (e: PackageManager.NameNotFoundException) {
      false
    }
  }

  private fun notifyPdfDownloaded(context: Context, fileName: String, uri: Uri?) {
    try {
      val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
          NOTIFICATION_CHANNEL_ID,
          NOTIFICATION_CHANNEL_NAME,
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
          description = "Notifications for downloaded statement PDFs"
        }
        notificationManager.createNotificationChannel(channel)
      }

      val openIntent = uri?.let {
        Intent(Intent.ACTION_VIEW).apply {
          setDataAndType(it, "application/pdf")
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      }

      val pendingIntent = openIntent?.let {
        PendingIntent.getActivity(
          context,
          0,
          it,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
      }

      val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("PDF Downloaded")
        .setContentText(fileName)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)
        .build()

      notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    } catch (_: Exception) {
      // Non-critical notification failure
    }
  }
}
