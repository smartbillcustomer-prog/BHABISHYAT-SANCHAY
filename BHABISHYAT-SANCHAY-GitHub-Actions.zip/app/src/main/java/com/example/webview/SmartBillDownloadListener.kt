package com.example.webview

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebView
import android.widget.Toast

class SmartBillDownloadListener(
  private val context: Context,
  private val webViewProvider: () -> WebView?
) : DownloadListener {

  override fun onDownloadStart(
    url: String?,
    userAgent: String?,
    contentDisposition: String?,
    mimetype: String?,
    contentLength: Long
  ) {
    if (url.isNullOrBlank()) return

    // CRITICAL: Handle JavaScript Blob URLs and Data URLs without DownloadManager crash
    if (url.startsWith("blob:", ignoreCase = true) || url.startsWith("data:", ignoreCase = true)) {
      handleBlobOrDataDownload(url, contentDisposition, mimetype)
      return
    }

    // Normal HTTP / HTTPS download
    try {
      val filename = URLUtil.guessFileName(url, contentDisposition, mimetype)
      val request = DownloadManager.Request(Uri.parse(url)).apply {
        setMimeType(mimetype ?: "application/pdf")
        addRequestHeader("User-Agent", userAgent)
        setDescription("Downloading $filename from BHABISHYAT SANCHAY…")
        setTitle(filename)
        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
      }

      val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
      downloadManager?.enqueue(request)

      Toast.makeText(context, "Downloading $filename…", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
      Toast.makeText(
        context,
        "Download failed: ${e.localizedMessage ?: "Unknown error"}",
        Toast.LENGTH_LONG
      ).show()
    }
  }

  private fun handleBlobOrDataDownload(
    url: String,
    contentDisposition: String?,
    mimetype: String?
  ) {
    val guessedName = PdfManager.sanitizeFileName(
      URLUtil.guessFileName(url, contentDisposition, mimetype ?: "application/pdf")
    )

    val webView = webViewProvider()
    if (webView == null) {
      Toast.makeText(context, "Cannot retrieve download: Page is not active", Toast.LENGTH_SHORT).show()
      return
    }

    Toast.makeText(context, "Preparing PDF download…", Toast.LENGTH_SHORT).show()

    // Execute script inside the document origin that created the blob
    val jsScript = """
      (function() {
        var blobUrl = '$url';
        var fileName = '$guessedName';
        var mime = '${mimetype ?: "application/pdf"}';
        
        if (blobUrl.startsWith('data:')) {
          if (window.AndroidPdfBridge) {
            window.AndroidPdfBridge.onPdfBlobReceived(blobUrl, fileName, mime, 'download');
          }
          return;
        }

        fetch(blobUrl)
          .then(function(res) {
            if (!res.ok) throw new Error('Fetch failed with status ' + res.status);
            return res.blob();
          })
          .then(function(blob) {
            var reader = new FileReader();
            reader.onloadend = function() {
                var base64data = reader.result;
                if (!base64data) {
                  if (window.AndroidPdfBridge) window.AndroidPdfBridge.onPdfBlobError('Empty blob data');
                  return;
                }
                var base64Str = base64data.indexOf(',') !== -1 ? base64data.split(',')[1] : base64data;
                var chunkSize = 256 * 1024; // 256 KB chunking
                if (base64Str.length > chunkSize) {
                  var totalChunks = Math.ceil(base64Str.length / chunkSize);
                  var transferId = 't_' + Date.now();
                  if (window.AndroidPdfBridge) {
                    window.AndroidPdfBridge.startChunkedTransfer(transferId, totalChunks, fileName, mime, 'download');
                    for (var i = 0; i < totalChunks; i++) {
                      var chunk = base64Str.substr(i * chunkSize, chunkSize);
                      window.AndroidPdfBridge.receiveChunk(transferId, i, chunk);
                    }
                    window.AndroidPdfBridge.finalizeTransfer(transferId);
                  }
                } else {
                  if (window.AndroidPdfBridge) {
                    window.AndroidPdfBridge.onPdfBlobReceived(base64data, fileName, mime, 'download');
                  }
                }
            };
            reader.onerror = function(err) {
              if (window.AndroidPdfBridge) window.AndroidPdfBridge.onPdfBlobError('FileReader error');
            };
            reader.readAsDataURL(blob);
          })
          .catch(function(err) {
            if (window.AndroidPdfBridge) {
              window.AndroidPdfBridge.onPdfBlobError('Blob fetch error: ' + (err ? err.message : 'Unknown'));
            }
          });
      })();
    """.trimIndent()

    webView.evaluateJavascript(jsScript, null)
  }
}
