package com.example.webview

object SmartBillConstants {
  const val BASE_URL = "https://smartbill-vytm.onrender.com/"
  const val ALLOWED_HOST = "smartbill-vytm.onrender.com"
  const val ALLOWED_HOST_1 = "smartbill-vytm.onrender.com"
  const val ALLOWED_HOST_2 = "smartbill-ljx7.onrender.com"
  const val APP_USER_AGENT_TAG = "BHABISHYAT-SANCHAY-Android/1.0"

  fun isAllowedHost(host: String?): Boolean {
    if (host.isNullOrBlank()) return false
    val lower = host.lowercase()
    return lower == ALLOWED_HOST_1 ||
           lower == ALLOWED_HOST_2 ||
           lower.endsWith(".onrender.com")
  }
}

sealed interface WebViewErrorState {
  data object None : WebViewErrorState
  data class Offline(val failingUrl: String?) : WebViewErrorState
  data class SslError(val failingUrl: String?, val description: String) : WebViewErrorState
  data class GeneralError(val failingUrl: String?, val errorCode: Int, val description: String) : WebViewErrorState
}
