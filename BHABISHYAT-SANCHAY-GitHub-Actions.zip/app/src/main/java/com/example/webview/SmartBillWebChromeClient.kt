package com.example.webview

import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class SmartBillWebChromeClient(
  private val onProgressUpdate: (progress: Int) -> Unit,
  private val onOpenFileChooser: (
    filePathCallback: ValueCallback<Array<Uri>>?,
    fileChooserParams: FileChooserParams?
  ) -> Boolean
) : WebChromeClient() {

  override fun onProgressChanged(view: WebView?, newProgress: Int) {
    super.onProgressChanged(view, newProgress)
    onProgressUpdate(newProgress)
  }

  override fun onShowFileChooser(
    webView: WebView?,
    filePathCallback: ValueCallback<Array<Uri>>?,
    fileChooserParams: FileChooserParams?
  ): Boolean {
    return onOpenFileChooser(filePathCallback, fileChooserParams)
  }
}
