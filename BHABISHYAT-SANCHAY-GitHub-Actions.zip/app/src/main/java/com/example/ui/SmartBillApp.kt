package com.example.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.network.NetworkConnectivityObserver
import com.example.webview.AndroidPdfBridge
import com.example.webview.SmartBillConstants
import com.example.webview.SmartBillDownloadListener
import com.example.webview.SmartBillWebChromeClient
import com.example.webview.SmartBillWebViewClient
import com.example.webview.WebViewErrorState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SmartBillApp(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val connectivityObserver = remember { NetworkConnectivityObserver(context) }
  val isOnline by connectivityObserver.observe().collectAsState(initial = connectivityObserver.isConnected())

  var webViewInstance by remember { mutableStateOf<WebView?>(null) }
  var canGoBack by remember { mutableStateOf(false) }
  var isLoading by remember { mutableStateOf(true) }
  var progress by remember { mutableIntStateOf(0) }
  var errorState by remember { mutableStateOf<WebViewErrorState>(WebViewErrorState.None) }
  var isRetrying by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()

  // File upload callback handling for WebChromeClient.onShowFileChooser
  var fileUploadCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

  val fileChooserLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      val data = result.data
      val uris: Array<Uri>? = when {
        data?.clipData != null -> {
          val clip = data.clipData!!
          Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
        }
        data?.data != null -> arrayOf(data.data!!)
        else -> null
      }
      fileUploadCallback?.onReceiveValue(uris)
    } else {
      fileUploadCallback?.onReceiveValue(null)
    }
    fileUploadCallback = null
  }

  // Automatic recovery when network reconnects after an offline error
  LaunchedEffect(isOnline) {
    if (isOnline && errorState is WebViewErrorState.Offline) {
      delay(500)
      errorState = WebViewErrorState.None
      webViewInstance?.reload()
    }
  }

  // Back button handling
  BackHandler(enabled = (errorState !is WebViewErrorState.None) || canGoBack) {
    if (errorState !is WebViewErrorState.None) {
      // Clear error state and attempt reload
      errorState = WebViewErrorState.None
      if (webViewInstance?.canGoBack() == true) {
        webViewInstance?.goBack()
      } else {
        webViewInstance?.loadUrl(SmartBillConstants.BASE_URL)
      }
    } else if (webViewInstance?.canGoBack() == true) {
      webViewInstance?.goBack()
    }
  }

  // Handle retry action
  val onRetry = {
    coroutineScope.launch {
      isRetrying = true
      errorState = WebViewErrorState.None
      delay(300)
      if (webViewInstance != null) {
        val currentUrl = webViewInstance?.url
        if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") {
          webViewInstance?.loadUrl(SmartBillConstants.BASE_URL)
        } else {
          webViewInstance?.reload()
        }
      }
      delay(800)
      isRetrying = false
    }
  }

  val statusBarPadding = WindowInsets.statusBars.asPaddingValues()
  val navBarPadding = WindowInsets.navigationBars.asPaddingValues()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(
        top = statusBarPadding.calculateTopPadding(),
        bottom = navBarPadding.calculateBottomPadding()
      )
  ) {
    // Persistent WebView
    AndroidView(
      modifier = Modifier
        .fillMaxSize()
        .testTag("smartbill_webview"),
      factory = { ctx ->
        WebView(ctx).apply {
          layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
          setBackgroundColor(AndroidColor.WHITE)

          // Configure WebSettings
          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            javaScriptCanOpenWindowsAutomatically = true

            // Strict HTTPS and sandbox security
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            safeBrowsingEnabled = true

            // App identifier in User Agent
            val defaultUa = userAgentString ?: ""
            userAgentString = "$defaultUa ${SmartBillConstants.APP_USER_AGENT_TAG}"
          }

          // Register native bridge for PDF generation, printing, and sharing
          val pdfBridge = AndroidPdfBridge(
            context = ctx,
            webViewProvider = { webViewInstance ?: this },
            originChecker = { url }
          )
          addJavascriptInterface(pdfBridge, "AndroidPdfBridge")

          // Disable WebView remote debugging for production security
          WebView.setWebContentsDebuggingEnabled(false)

          // Modern persistent cookie management
          val cookieManager = CookieManager.getInstance()
          cookieManager.setAcceptCookie(true)
          cookieManager.setAcceptThirdPartyCookies(this, true)

          // Download listener with Blob URL extraction support
          val customDownloadListener = SmartBillDownloadListener(ctx) { webViewInstance ?: this }
          setDownloadListener(customDownloadListener)

          // WebChromeClient
          webChromeClient = SmartBillWebChromeClient(
            onProgressUpdate = { newProgress ->
              progress = newProgress
            },
            onOpenFileChooser = { callback, params ->
              fileUploadCallback?.onReceiveValue(null) // Cancel any previous
              fileUploadCallback = callback

              val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
              }

              try {
                fileChooserLauncher.launch(intent)
                true
              } catch (e: Exception) {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = null
                false
              }
            }
          )

          // WebViewClient with Blob URL interception
          webViewClient = SmartBillWebViewClient(
            context = ctx,
            onLoadingChanged = { loading ->
              isLoading = loading
              canGoBack = this.canGoBack()
            },
            onErrorStateChanged = { newError ->
              errorState = newError
            },
            onPageFinishedTitle = { _, _ ->
              canGoBack = this.canGoBack()
            },
            onBlobUrlIntercepted = { blobUrl ->
              customDownloadListener.onDownloadStart(
                blobUrl,
                settings.userAgentString,
                null,
                "application/pdf",
                0L
              )
            }
          )

          webViewInstance = this
          loadUrl(SmartBillConstants.BASE_URL)
        }
      },
      update = { view ->
        webViewInstance = view
        canGoBack = view.canGoBack()
      }
    )

    // Top progress loading bar
    TopLoadingBar(
      isLoading = isLoading,
      progress = progress,
      modifier = Modifier.align(Alignment.TopCenter)
    )

    // Smooth error overlay transition
    Crossfade(
      targetState = errorState,
      label = "errorStateCrossfade"
    ) { state ->
      if (state !is WebViewErrorState.None) {
        ErrorScreen(
          errorState = state,
          isOnline = isOnline,
          isRetrying = isRetrying,
          onRetry = { onRetry() }
        )
      }
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      fileUploadCallback?.onReceiveValue(null)
      fileUploadCallback = null
    }
  }
}
