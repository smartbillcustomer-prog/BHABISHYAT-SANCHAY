package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate800
import com.example.ui.theme.SmartBillEmerald
import com.example.ui.theme.SmartBillNavy
import com.example.ui.theme.SmartBillRose
import com.example.webview.WebViewErrorState

@Composable
fun ErrorScreen(
  errorState: WebViewErrorState,
  isOnline: Boolean,
  isRetrying: Boolean,
  onRetry: () -> Unit,
  modifier: Modifier = Modifier
) {
  val title = when (errorState) {
    is WebViewErrorState.Offline -> "No Internet Connection"
    is WebViewErrorState.SslError -> "Security Warning"
    is WebViewErrorState.GeneralError -> "Unable to Connect"
    WebViewErrorState.None -> "Connecting to SMARTBILL"
  }

  val description = when (errorState) {
    is WebViewErrorState.Offline ->
      "Unable to reach the SMARTBILL service. Please check your Wi-Fi or mobile data connection and try again."
    is WebViewErrorState.SslError ->
      "A secure SSL connection to SMARTBILL could not be validated (${errorState.description}). For your security, access was blocked."
    is WebViewErrorState.GeneralError ->
      if (errorState.description.isNotBlank()) errorState.description
      else "Could not load SMARTBILL. Please verify your internet connection and retry."
    WebViewErrorState.None ->
      "Loading the latest financial dashboard and account data."
  }

  val isSsl = errorState is WebViewErrorState.SslError

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      modifier = Modifier
        .widthIn(max = 480.dp)
        .fillMaxWidth()
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      // Offline / Error Illustration Card
      Surface(
        modifier = Modifier
          .size(200.dp)
          .clip(RoundedCornerShape(28.dp)),
        color = Slate200.copy(alpha = 0.5f),
        shadowElevation = 2.dp
      ) {
        Box(contentAlignment = Alignment.Center) {
          Image(
            painter = painterResource(id = R.drawable.smartbill_offline_illustration_1794107415736),
            contentDescription = "Connection Status Illustration",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Status Pill
      Surface(
        shape = CircleShape,
        color = if (isOnline) SmartBillEmerald.copy(alpha = 0.12f) else SmartBillRose.copy(alpha = 0.12f),
        modifier = Modifier.padding(bottom = 12.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (isOnline) SmartBillEmerald else SmartBillRose)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isOnline) "Internet Connected" else "Device Offline",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (isOnline) SmartBillEmerald else SmartBillRose
          )
        }
      }

      // Title
      Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Subtitle / Description
      Text(
        text = description,
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center,
        color = Slate600,
        lineHeight = 22.sp,
        modifier = Modifier.padding(horizontal = 8.dp)
      )

      Spacer(modifier = Modifier.height(32.dp))

      // Action Button
      Button(
        onClick = onRetry,
        enabled = !isRetrying,
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("retry_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isSsl) Slate800 else SmartBillNavy
        ),
        shape = RoundedCornerShape(14.dp)
      ) {
        if (isRetrying) {
          CircularProgressIndicator(
            modifier = Modifier.size(22.dp),
            strokeWidth = 2.5.dp,
            color = MaterialTheme.colorScheme.onPrimary
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Reconnecting…",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold
          )
        } else {
          Icon(
            imageVector = if (isSsl) Icons.Default.Lock else Icons.Default.Refresh,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = if (isSsl) "Retry Security Check" else "Retry Connection",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }
  }
}
