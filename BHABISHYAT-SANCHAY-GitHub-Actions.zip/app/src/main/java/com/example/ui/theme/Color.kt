package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SmartBillNavy = Color(0xFF0A2540)
val SmartBillBlue = Color(0xFF1D4ED8)
val SmartBillTeal = Color(0xFF0284C7)
val SmartBillEmerald = Color(0xFF10B981)
val SmartBillAmber = Color(0xFFF59E0B)
val SmartBillRose = Color(0xFFEF4444)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)

val PrimaryLight = Color(0xFF0A2540)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDCE2F9)
val OnPrimaryContainerLight = Color(0xFF001944)

val PrimaryDark = Color(0xFFB4C5FF)
val OnPrimaryDark = Color(0xFF002A78)
val PrimaryContainerDark = Color(0xFF0A2540)
val OnPrimaryContainerDark = Color(0xFFDCE2F9)
