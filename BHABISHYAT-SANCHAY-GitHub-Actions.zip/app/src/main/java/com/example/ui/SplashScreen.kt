package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import com.example.R
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onTimeout: () -> Unit,
  modifier: Modifier = Modifier
) {
  // Prevent unintended navigation during the initial 5-second splash
  BackHandler(enabled = true) {
    // Keep splash on screen or exit if requested
  }

  // Show for exactly 5 seconds (5000 ms) on fresh launch
  LaunchedEffect(Unit) {
    delay(5000L)
    onTimeout()
  }

  val backgroundBrush = remember {
    Brush.verticalGradient(
      listOf(
        Color(0xFF0F022E),
        Color(0xFF14023D),
        Color(0xFF190157)
      )
    )
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(backgroundBrush)
      .testTag("splash_screen"),
    contentAlignment = Alignment.Center
  ) {
    Image(
      painter = painterResource(id = R.drawable.splash_bhabishyat_sanchay),
      contentDescription = "WELCOME TO BHABISHYAT SANCHAY",
      modifier = Modifier.fillMaxSize(),
      contentScale = ContentScale.Fit
    )
  }
}
