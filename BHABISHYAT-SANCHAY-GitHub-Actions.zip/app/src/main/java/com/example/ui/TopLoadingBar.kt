package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.SmartBillBlue
import com.example.ui.theme.SmartBillTeal

@Composable
fun TopLoadingBar(
  isLoading: Boolean,
  progress: Int,
  modifier: Modifier = Modifier
) {
  val animatedProgress by animateFloatAsState(
    targetValue = (progress.coerceIn(0, 100)) / 100f,
    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
    label = "webViewProgress"
  )

  AnimatedVisibility(
    visible = isLoading && progress < 100,
    enter = fadeIn(animationSpec = tween(150)),
    exit = fadeOut(animationSpec = tween(300)),
    modifier = modifier
  ) {
    LinearProgressIndicator(
      progress = { animatedProgress },
      modifier = Modifier
        .fillMaxWidth()
        .height(3.dp)
        .testTag("loading_progress_bar"),
      color = SmartBillBlue,
      trackColor = SmartBillTeal.copy(alpha = 0.2f),
      strokeCap = StrokeCap.Round
    )
  }
}
