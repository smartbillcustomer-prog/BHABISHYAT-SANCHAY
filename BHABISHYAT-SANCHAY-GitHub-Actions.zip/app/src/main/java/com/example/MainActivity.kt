package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.SmartBillApp
import com.example.ui.SplashScreen
import com.example.ui.theme.SMARTBILLTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      SMARTBILLTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          // Display splash screen once on each fresh app launch
          var showSplash by rememberSaveable { mutableStateOf(true) }

          Box(modifier = Modifier.fillMaxSize()) {
            // Original website dashboard remains completely unmodified
            SmartBillApp()

            // Separate full-screen splash screen overlay showing for exactly 5 seconds
            AnimatedVisibility(
              visible = showSplash,
              enter = fadeIn(animationSpec = tween(150)),
              exit = fadeOut(animationSpec = tween(400))
            ) {
              SplashScreen(
                onTimeout = { showSplash = false }
              )
            }
          }
        }
      }
    }
  }
}
