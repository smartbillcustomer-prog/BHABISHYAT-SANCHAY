package com.example.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

interface ConnectivityObserver {
  fun observe(): Flow<Boolean>
  fun isConnected(): Boolean
}

class NetworkConnectivityObserver(
  private val context: Context
) : ConnectivityObserver {

  private val connectivityManager =
    context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

  override fun observe(): Flow<Boolean> = callbackFlow {
    val callback = object : ConnectivityManager.NetworkCallback() {
      override fun onAvailable(network: Network) {
        super.onAvailable(network)
        trySend(true)
      }

      override fun onLost(network: Network) {
        super.onLost(network)
        trySend(isConnected())
      }

      override fun onUnavailable() {
        super.onUnavailable()
        trySend(false)
      }
    }

    // Emit initial status
    trySend(isConnected())

    val request = NetworkRequest.Builder()
      .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
      .build()

    connectivityManager.registerNetworkCallback(request, callback)

    awaitClose {
      connectivityManager.unregisterNetworkCallback(callback)
    }
  }.distinctUntilChanged()

  override fun isConnected(): Boolean {
    val activeNetwork = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
      (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
       capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
       capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
  }
}
