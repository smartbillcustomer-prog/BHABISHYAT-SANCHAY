package com.example

import com.example.webview.PdfManager
import com.example.webview.SmartBillConstants
import com.example.webview.WebViewErrorState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `verify base url uses secure https protocol`() {
    assertTrue(SmartBillConstants.BASE_URL.startsWith("https://"))
    assertEquals("https://smartbill-vytm.onrender.com/", SmartBillConstants.BASE_URL)
  }

  @Test
  fun `verify allowed host matches render domain`() {
    assertEquals("smartbill-vytm.onrender.com", SmartBillConstants.ALLOWED_HOST)
    assertTrue(SmartBillConstants.isAllowedHost("smartbill-vytm.onrender.com"))
    assertTrue(SmartBillConstants.isAllowedHost("smartbill-ljx7.onrender.com"))
    assertFalse(SmartBillConstants.isAllowedHost("malicious-site.com"))
  }

  @Test
  fun `verify user agent identifier format`() {
    assertTrue(SmartBillConstants.APP_USER_AGENT_TAG.contains("BHABISHYAT"))
    assertTrue(SmartBillConstants.APP_USER_AGENT_TAG.contains("Android"))
  }

  @Test
  fun `verify pdf filename sanitization prevents path traversal`() {
    val traversal = "../../../etc/passwd.pdf"
    val sanitized = PdfManager.sanitizeFileName(traversal)
    assertFalse(sanitized.contains("/"))
    assertFalse(sanitized.contains(".."))
    assertTrue(sanitized.endsWith(".pdf"))

    val safeName = "Daily_Collection_Statement_2026.pdf"
    assertEquals("Daily_Collection_Statement_2026.pdf", PdfManager.sanitizeFileName(safeName))

    val noExt = "Customer_Statement_1001"
    assertEquals("Customer_Statement_1001.pdf", PdfManager.sanitizeFileName(noExt))

    val emptyName = ""
    assertEquals("BHABISHYAT_SANCHAY_Statement.pdf", PdfManager.sanitizeFileName(emptyName))
  }

  @Test
  fun `verify base64 decoding with data URI prefix`() {
    // "%PDF-1.4" encoded in base64 is "JVBERi0xLjQ="
    val dataUri = "data:application/pdf;base64,JVBERi0xLjQ="
    val bytes = PdfManager.decodeBase64Pdf(dataUri)
    assertNotNull(bytes)
    assertEquals("%PDF-1.4", String(bytes!!))

    val rawBase64 = "JVBERi0xLjQ="
    val rawBytes = PdfManager.decodeBase64Pdf(rawBase64)
    assertNotNull(rawBytes)
    assertEquals("%PDF-1.4", String(rawBytes!!))

    val invalidData = "invalid&&&base64%%"
    val invalidBytes = PdfManager.decodeBase64Pdf(invalidData)
    // Should be handled gracefully
    assertNull(invalidBytes)
  }

  @Test
  fun `verify webview error states initialization`() {
    val noneState = WebViewErrorState.None
    assertEquals(WebViewErrorState.None, noneState)

    val offline = WebViewErrorState.Offline("https://smartbill-vytm.onrender.com/login")
    assertEquals("https://smartbill-vytm.onrender.com/login", offline.failingUrl)

    val sslError = WebViewErrorState.SslError("https://smartbill-vytm.onrender.com/dashboard", "Expired cert")
    assertEquals("Expired cert", sslError.description)

    val generalError = WebViewErrorState.GeneralError("https://smartbill-vytm.onrender.com/", 500, "Server Error")
    assertEquals(500, generalError.errorCode)
  }
}
