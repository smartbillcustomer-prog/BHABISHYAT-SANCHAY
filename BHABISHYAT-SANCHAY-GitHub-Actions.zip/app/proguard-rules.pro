# Project-specific ProGuard / R8 rules for BHABISHYAT SANCHAY

# Preserve WebView callbacks and Javascript interfaces
-keepclassmembers class * extends android.webkit.WebViewClient {
    public *;
}
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public *;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.example.webview.AndroidPdfBridge {
    public *;
}

# Preserve line number information for Google Play Console crash de-obfuscation
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Preserve cryptographic provider and network security trust anchors
-keepclassmembers class * extends java.security.Provider {
    public *;
}
